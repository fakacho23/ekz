import pymysql
from tkinter import *
from tkinter import ttk
import tkinter as tk
from config import *
import table
import adm
import client

connection = pymysql.connect(
    host=host,
    user=user,
    password=password,
    database=db_name,
    cursorclass=pymysql.cursors.DictCursor
)


# tree.heading('', text = '')


window = Tk()
window.title('Главное меню')
window.geometry('800x500+500+200')

b1 = Button(window, text='Фильмы', font='Times 12', width=10, command=table.table_client)
b1.place(x=115, y=400)


b2 = Button(window, text='Админ', font='Times 12', width=10, command=adm.click_adm)
b2.place(x=315, y=400)

b3 = Button(window, text='Пользователь', font='Times 12', width=10, command=client.user)
b3.place(x=515, y=400)

window.mainloop()

