
import pymysql
from tkinter import *
from tkinter import ttk
import tkinter as tk
from config import *

connection = pymysql.connect(
    host=host,
    user=user,
    password=password,
    database=db_name,
    cursorclass=pymysql.cursors.DictCursor
)


def user():
    def user1():
        with connection.cursor() as cur:
            user_log = format(en_telep.get())
            log = f"SELECT * FROM client WHERE telephone = '{user_log}'"
            cur.execute(log)
            res = cur.fetchall()
            for i in res:
                res2 = i['id_client']
            if res:
                columns = ('hall_ticket', 'place_ticket', 'date_buy', 'kod_client', 'kod_session')
                tree = ttk.Treeview(user_win, columns=columns, show='headings')
                tree.heading('hall_ticket', text='Зал')
                tree.heading('place_ticket', text='Место')
                tree.heading('date_buy', text='Дата покупки')
                tree.heading('kod_client', text='Клиент')
                tree.heading('kod_session', text='Фильм')
                users = f"SELECT * FROM ticket, session, client WHERE ticket.kod_client = client.id_client AND ticket.kod_session = session.id_session AND ticket.kod_client = '{res2}'"
                cur.execute(users)
                res = cur.fetchall()
                tree.place(x=1, y=1)
                for row in res:
                    a = (row['hall_ticket'])
                    b = (row['place_ticket'])
                    c = (row['date_buy'])
                    d = (row['fio'])
                    e = (row['film_session'])
                    f = [(a), (b), (c), (d), (e)]
                    tree.insert("", tk.END, values=(f))

    user_win = Tk()
    user_win.title('Вход пользователя')
    user_win.geometry('1200x600+500+300')

    but_telep = Button(user_win, font='Times 16', text='Ввести', command=user1)
    but_telep.place(x=100, y=300)
    en_telep = Entry(user_win, font='Times 16')
    en_telep.place(x=300, y=300)

    user_win.mainloop()