import pymysql
from tkinter import *
from tkinter import ttk
import tkinter as tk
from config import *

connection = pymysql.connect(
    host=host,
    user=user,
    password=password,
    database=db_name,
    cursorclass=pymysql.cursors.DictCursor
)


def click_adm():
    def click_adm1():
        with connection.cursor() as cur:
            adm_log = format(en_log.get())
            adm_pass = format(en_pass.get())
            log = f"SELECT * FROM admin WHERE log = '{adm_log}' AND pass = '{adm_pass}'"
            cur.execute(log)
            res = cur.fetchall()
            if res:
                adm_win.destroy()
                adm_win1 = Tk()
                adm_win1.title('Данные о клиентах')
                adm_win1.geometry('1200x500+500+300')
                adm_win1.configure(bg='grey')

                def add():
                    fio_add = format(en_add_fio.get())
                    tele_add = format(en_add_tel.get())
                    passp_add = format(en_add_passp.get())
                    adds = f"INSERT INTO client (fio, telephone, passport) VALUES ('{fio_add}', '{tele_add}', '{passp_add}')"
                    cur.execute(adds)
                    connection.commit()

                en_add_fio = Entry(adm_win1, font='Times 16')
                en_add_fio.place(x=800, y=100)
                en_add_tel = Entry(adm_win1, font='Times 16')
                en_add_tel.place(x=800, y=150)
                en_add_passp = Entry(adm_win1, font='Times 16')
                en_add_passp.place(x=800, y=200)
                lb_add_fio = Label(adm_win1, font='Times 16', bg='grey', text='ФИО')
                lb_add_fio.place(x=650, y=100)
                lb_add_tel = Label(adm_win1, font='Times 16', bg='grey', text='Телефон')
                lb_add_tel.place(x=650, y=150)
                lb_add_passp = Label(adm_win1, font='Times 16', bg='grey', text='Паспорт')
                lb_add_passp.place(x=650, y=200)
                but_add = Button(adm_win1, font='Times 16', text='Внести клиента', command=add)
                but_add.place(x=400, y=300)
                columns = ('fio', 'telephone', 'passport')
                tree = ttk.Treeview(adm_win1, columns=columns, show='headings')
                tree.heading('fio', text='ФИО')
                tree.heading('telephone', text='Номер телефона')
                tree.heading('passport', text='Паспорт')
                clients = f"SELECT * FROM client"
                cur.execute(clients)
                res = cur.fetchall()
                tree.place(x=1, y=1)
                for row in res:
                    a = (row['fio'])
                    b = (row['telephone'])
                    c = (row['passport'])
                    d = [(a), (b), (c)]
                    tree.insert("", tk.END, values=(d))
                adm_win1.mainloop()

    adm_win = Tk()
    adm_win.title('Вход администратора')
    adm_win.geometry('400x400+500+300')

    b_adm = Button(adm_win, text='Вход', font='Times 12', width=15, command=click_adm1)
    b_adm.place(x=150, y=300)

    en_log = Entry(adm_win, font='Times 16')
    en_log.place(x=100, y=100)

    en_pass = Entry(adm_win, font='Times 16')
    en_pass.place(x=100, y=200)
