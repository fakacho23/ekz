import pymysql
from tkinter import *
from tkinter import ttk
import tkinter as tk
from config import *

connection = pymysql.connect(
    host=host,
    user=user,
    password=password,
    database=db_name,
    cursorclass=pymysql.cursors.DictCursor
)


def table_client():
    with connection.cursor() as cur:
        columns = ('date_session', 'time_session', 'film_session', 'kod_genre')
        tree = ttk.Treeview(columns=columns, show='headings')
        tree.heading('date_session', text='Дата сеанса')
        tree.heading('time_session', text='Время сеанса')
        tree.heading('film_session', text='Фильм')
        tree.heading('kod_genre', text='Жанр')
        films = f"SELECT * FROM session, genre WHERE session.kod_genre=genre.id_genre"
        cur.execute(films)
        res = cur.fetchall()
        tree.place(x=1, y=1)
        for row in res:
            a = (row['date_session'])
            b = (row['time_session'])
            c = (row['film_session'])
            d = (row['name_genre'])
            e = [(a), (b), (c), (d)]
            tree.insert("", tk.END, values=(e))